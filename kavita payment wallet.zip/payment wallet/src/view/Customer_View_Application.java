package view;

import java.math.BigDecimal;

import service.Customer_Wallet_Service;
import service.Customer_Wallet_Service_Implementation;
import  exception.CustomerNameCanNotBeNullExceptions;
import  exception.DuplicateMobileNumberExceptions;
import  exception.InsufficientBalanceExceptions;
import  exception.MobileNumberCanNotBeNullExceptions;
import  exception.MobileNumberDoesNotExistExceptions;


public class Customer_View_Application {

	public static void main(String[] args) throws CustomerNameCanNotBeNullExceptions, DuplicateMobileNumberExceptions, InsufficientBalanceExceptions, MobileNumberCanNotBeNullExceptions, MobileNumberDoesNotExistExceptions, service.MobileNumberDoesNotExistExceptions, service.MobileNumberCanNotBeNullExceptions, service.DuplicateMobileNumberExceptions, service.CustomerNameCanNotBeNullExceptions, service.InsufficientBalanceExceptions{
		
		Customer_Wallet_Service cust_wallet_serv = new Customer_Wallet_Service_Implementation();
		
		//System.out.println(cust_wallet_serv.CreateCustomerAccount("ADITYA", "1", new BigDecimal("10000")));
		cust_wallet_serv.CreateCustomerAccount("ARMAN", "2", new BigDecimal("15000"));
		
		System.out.println(cust_wallet_serv.ShowCustomerBalance("1").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.DepositAmount("2",new BigDecimal("30000"));
		cust_wallet_serv.DepositAmount("2",new BigDecimal("40000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.WithdrawAmount("1",new BigDecimal("20000"));
		cust_wallet_serv.WithdrawAmount("2",new BigDecimal("20000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2").getCustomer_Wallet().getCustomer_Balance());

		cust_wallet_serv.FundTransfer("1", "2",new BigDecimal("20000"));

		System.out.println(cust_wallet_serv.ShowCustomerBalance("1").getCustomer_Wallet().getCustomer_Balance());
		System.out.println(cust_wallet_serv.ShowCustomerBalance("2").getCustomer_Wallet().getCustomer_Balance());
		
		
	}

}


