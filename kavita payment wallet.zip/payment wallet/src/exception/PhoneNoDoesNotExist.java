package exception;

public class PhoneNoDoesNotExist {

}
