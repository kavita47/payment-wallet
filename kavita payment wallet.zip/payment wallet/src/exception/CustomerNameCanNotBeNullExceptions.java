package exception;

public class CustomerNameCanNotBeNullExceptions extends Exception {

}
