package exception;

public class MobileNumberDoesNotExistExceptions extends Exception {

}
