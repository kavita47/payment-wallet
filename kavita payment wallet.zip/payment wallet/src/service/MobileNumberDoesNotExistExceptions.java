package service;

public class MobileNumberDoesNotExistExceptions extends Exception {

}
