package exception;

public class MobileNumberCanNotBeNullExceptions extends Exception {

}
