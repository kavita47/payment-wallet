package exception;

public class InsufficientBalanceExceptions extends Exception {

}
