package exception;

public class DuplicateMobileNumberExceptions extends Exception {

}
