package service;

public class InsufficientBalanceExceptions extends Exception {

}
