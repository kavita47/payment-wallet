package service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;

import repository.Customer_Wallet_Repository;


public class Customer_Wallet_Service_Implementation implements Customer_Wallet_Service{
	
	
	Customer_Wallet_Repository cust_wallet_repo;
	Wallet wallet;
	@Override
	public Customer CreateCustomerAccount(String Customer_Name, String Customer_MobileNo, BigDecimal Customer_Balance) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Customer ShowCustomerBalance(String Customer_MobileNo) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Customer FundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Customer DepositAmount(String Customer_MobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Customer WithdrawAmount(String Customer_MobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}
	




	
	

}
