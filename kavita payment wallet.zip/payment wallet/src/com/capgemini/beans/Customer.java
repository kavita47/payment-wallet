package com.capgemini.beans;

public class Customer {

	private String Customer_Name;
	private String Customer_MobileNo;
	private Wallet Customer_Wallet;
	
	
	
	public String getCustomer_Name() {
		return Customer_Name;
	}
	
	
	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}
	
	public String getCustomer_MobileNo() {
		return Customer_MobileNo;
	}
	
	public void setCustomer_MobileNo(String customer_MobileNo) {
		Customer_MobileNo = customer_MobileNo;
	}
	
	public Wallet getCustomer_Wallet() {
		return Customer_Wallet;
	}
	
	public void setCustomer_Wallet(Wallet customer_Wallet) {
		Customer_Wallet = customer_Wallet;
	}
	
	@Override
	public String toString() {
		return "Customer [Customer_Name=" + Customer_Name + ", Customer_MobileNo=" + Customer_MobileNo + "]";
	}
	

}
