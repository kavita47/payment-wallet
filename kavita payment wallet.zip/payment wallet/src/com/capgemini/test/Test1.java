package com.capgemini.test;
import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName;

import exception.CustomerNameCanNotBeNullExceptions;
import exception.DuplicateMobileNumberExceptions;
import exception.InsufficientBalanceExceptions;
import exception.MobileNumberCanNotBeNullExceptions;
import exception.MobileNumberDoesNotExistExceptions;
import repository.Customer_Wallet_Repository;
import repository.Customer_Wallet_Repository_Implementation;
import service.Customer_Wallet_Service;
import service.Customer_Wallet_Service_Implementation;

public class Test1 {
	Customer_Wallet_Repository wr=new Customer_Wallet_Repository_Implementation();
	Customer_Wallet_Service ws=new Customer_Wallet_Service_Implementation();
	
	@Before
	public void setUp() throws Exception {
	}

	
	
		
	@Test(expected=  DuplicateMobileNumberExceptions.class)
	public void test() throws DuplicateName, DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions
	{
		ws.CreateCustomerAccount("Kavita1", "1",new BigDecimal("10000.0"));
		ws.CreateCustomerAccount("Kavita2", "1",new BigDecimal("10000.0"));
		
	}
	@Test(expected=exception.MobileNumberDoesNotExistExceptions.class)
	public void test1() throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions, InsufficientBalanceExceptions
	{
		ws.WithdrawAmount("7",new BigDecimal("20000"));
		
		
	}
	
	@Test
	public void test3() throws DuplicateName, DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions 
	{
		ws.CreateCustomerAccount("Kavita1", "1",new BigDecimal("10000.0"));
		
		
	}
}
