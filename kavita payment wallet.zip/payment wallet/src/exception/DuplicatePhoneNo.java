package exception;

public class DuplicatePhoneNo {

}
