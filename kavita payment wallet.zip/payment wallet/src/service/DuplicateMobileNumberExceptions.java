package service;

public class DuplicateMobileNumberExceptions extends Exception {

}
