package repository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import java.util.Iterator;

import com.capgemini.beans.Customer;

public class Customer_Wallet_Repository_Implementation implements Customer_Wallet_Repository{

	
	LinkedList<Customer> l2 = new LinkedList<>();
	
	//Wallet wallet;
	
	@Override
	public Boolean Save_Customer(Customer customer) {
		//ll.add(customer.getCustomer_Name());
		//ll.add(customer.getCustomer_MobileNo());
		//ll.add(wallet.getCustomer_Balance());
		
		return l2.add(customer);
	}

	@Override
	public Customer FindOneCustomer(String Customer_MobileNo) {
		
		List<Customer> custlist = new ArrayList<>();
		Iterator< Customer> itr = custlist.iterator();
		while(itr.hasNext())
		{
			Customer customer = itr.next();
			if(customer.getCustomer_MobileNo().equals(Customer_MobileNo));
			{
				return customer;
			}
		}
		
		return null;
	}
}

