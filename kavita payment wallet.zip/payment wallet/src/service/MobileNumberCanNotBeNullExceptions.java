package service;

public class MobileNumberCanNotBeNullExceptions extends Exception {

}
