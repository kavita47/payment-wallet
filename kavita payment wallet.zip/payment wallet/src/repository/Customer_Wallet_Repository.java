package repository;

import com.capgemini.beans.Customer;

public interface Customer_Wallet_Repository {

	public Boolean Save_Customer(Customer customer);
	
	public Customer FindOneCustomer(String Customer_MobileNo);

}
