package com.capgemini.beans;

import java.math.BigDecimal;

public class Wallet {
	private BigDecimal Customer_Balance;

	/**
	 * @param customer_Balance
	 */
	public Wallet(BigDecimal customer_Balance) {
		super();
		Customer_Balance = customer_Balance;
	}

	@Override
	public String toString() {
		return "Wallet [Customer_Balance=" + Customer_Balance + "]";
	}

	public BigDecimal getCustomer_Balance() {
		return Customer_Balance;
	}

	public void setCustomer_Balance(BigDecimal customer_Balance) {
		Customer_Balance = customer_Balance;
	}

}
