package service;
import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import exception.CustomerNameCanNotBeNullExceptions;
import exception.DuplicateMobileNumberExceptions;
import exception.InsufficientBalanceExceptions;
import exception.MobileNumberCanNotBeNullExceptions;
import exception.MobileNumberDoesNotExistExceptions;


public interface Customer_Wallet_Service {
	
	public Customer CreateCustomerAccount(String Customer_Name, String Customer_MobileNo, BigDecimal Customer_Balance) throws DuplicateMobileNumberExceptions, MobileNumberCanNotBeNullExceptions, CustomerNameCanNotBeNullExceptions;
	public Customer ShowCustomerBalance(String Customer_MobileNo) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer FundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer DepositAmount(String Customer_MobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions;
	public Customer WithdrawAmount(String Customer_MobileNo, BigDecimal amount) throws MobileNumberDoesNotExistExceptions, MobileNumberCanNotBeNullExceptions, InsufficientBalanceExceptions;
	

}
