package service;

public class CustomerNameCanNotBeNullExceptions extends Exception {

}
